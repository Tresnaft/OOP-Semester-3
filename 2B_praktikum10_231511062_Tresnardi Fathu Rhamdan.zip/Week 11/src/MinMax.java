interface MinMax<T extends Comparable<T>> {
    T max(); /* w w w .java2 s . co m*/
}