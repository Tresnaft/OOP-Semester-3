public interface Refuelable {
    void refuel();
}
