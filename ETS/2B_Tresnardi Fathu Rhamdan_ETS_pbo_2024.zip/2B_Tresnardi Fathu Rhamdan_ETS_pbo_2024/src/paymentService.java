abstract class paymentService {
    abstract String getPaymentStatus();
    abstract String getPaymentMethod();
}
