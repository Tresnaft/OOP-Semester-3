public interface Observer<T> {
    void update(T state);
}
